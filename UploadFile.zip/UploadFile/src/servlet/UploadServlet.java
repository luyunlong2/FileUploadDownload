package servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class UploadServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		String name=request.getParameter("name");
//		String file=request.getParameter("file");
//		System.out.println(name);
//		System.out.println(file);
		
//		InputStream is=request.getInputStream();
//		byte[] b=new byte[1024];
//		int len=0;
//		while((len=is.read(b))!=-1){
//			System.out.println(new String(b,0,len));
//		}
		//�жϸ�ʽ�Ƿ���multipart/form-data
		boolean flag=ServletFileUpload.isMultipartContent(request);
		if(!flag){
			response.getWriter().write("��ʽ��֧���ϴ�");
		}
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload servlet=new ServletFileUpload(factory);
		try {
			List<FileItem> fileItems=servlet.parseRequest(request);
			for(FileItem fileItem:fileItems){
				if(fileItem.isFormField()){
					processFormField(fileItem);
				}else{
					processUploadField(fileItem);
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
		
	}

	private void processUploadField(FileItem fileItem) {
		try {
			InputStream is=fileItem.getInputStream();
			//����һ���ļ��洢Ŀ¼
			String directory=this.getServletContext().getRealPath("/web-inf/upload");
			File storeDirectory=new File(directory);
			if(!storeDirectory.exists()){
				storeDirectory.mkdirs();
			}
			String fileName=fileItem.getName();
			//�����ļ���
			fileName=fileName.substring(fileName.lastIndexOf(File.separator)+1);
			//�����ļ�����
			fileName=UUID.randomUUID()+"_"+fileName;
			//Ŀ¼��ɢ
			String childDirectory=makeChildDirectory(storeDirectory);
			
			File file=new File(storeDirectory,childDirectory+File.separator+fileName);
			FileOutputStream os=new FileOutputStream(file);
			int len=0;
			byte[] b=new byte[1024];
			while((len=is.read(b))!=-1){
				os.write(b,0,len);
			}
			is.close();
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	private String makeChildDirectory(File storeDirectory) {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String dateDirectory=sdf.format(new Date());
		File file=new File(storeDirectory,dateDirectory);
		if(!file.exists()){
			file.mkdirs();
		}
		return dateDirectory;
	}

	private void processFormField(FileItem fileItem) {
		String name=fileItem.getFieldName();
		String value=fileItem.getString();
		System.out.println("name="+value);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
